# installing shinydashboard package

library (shiny)
library(shinydashboard)
library(sqldf)
library(DT)
library(googleVis)
library(shinythemes)
library(plotly)

#Reading the dataset
setwd("C:/Users/Jane/Desktop/Trivago")
dataset<- read.csv("Case Study - Business Analyst - Advertiser Intelligence (2_2).csv", header= TRUE)
names(dataset)


#Calculating the total number of clicks and total trivago cost
#total_clicks<- sqldf('select insert_date, sum(clicks) as total_clicks from dataset group by insert_date')
#total_trivago_cost<- sum(dataset$cost)
#total_trivago_cost

#creating another column calculating the clicks share per POS
#dataset<- transform(dataset, clicks_share= clicks/total_clicks)
#names(dataset)

#creating another column calculating the cost share per POS
#dataset<- transform (dataset, cost_share= cost/total_trivago_cost)
#names(dataset)

#Agrregating POS 
#aggr_POS<- sqldf('select insert_date,pos,(sum(clicks) *100 / total_clicks) as Click_Share,(sum(cost)*100/total_trivago_cost) as Cost_Share from dataset group by insert_date, pos')
#aggr_POS


#Top_position share%
top_pos<- sqldf('select insert_date,POS, (sum(top_pos)* 100 / sum(partner_impressions)) as Top_Pos_Percentage from dataset group by insert_date, pos')
#top_pos

#Beat% share
beat<- sqldf('select insert_date as Date, pos as Pos_Code, (sum(beat)*100/ sum(beat+lose)) as Beat_Percentage from dataset group by insert_date,pos')
#beat

#partner impression percentage
partner<-sqldf('select insert_date as Date, pos as Pos_Code, (sum(partner_impressions)*100/ sum(hotel_impressions)) as Partner_Impressions_Percentage from dataset group by insert_date, pos')
#partner

#Calculating pricing of advertisers over time
dataset<- transform(dataset, pricing= hotel_impressions- (beat+meet+lose))
names(dataset)
adv_dev<- sqldf('select insert_date, adv_id, pos, pricing from dataset group by insert_date, adv_id, pos')

# Using Google API to create charts
#mychart<- gvisLineChart(adv_dev, options=list(gvis.editor="Edit this chart", width=1000, height= 600))
#plot(mychart)

ui <- fluidPage(
  titlePanel("Trivago Advertiser Dashboard"),
  verticalLayout(
    sidebarPanel(
      conditionalPanel(
        'input.data === "dataset"',
        checkboxGroupInput("POS", "Columns in the dataset to show:",
                           names(dataset), selected = names(dataset))
      )
      ),
      
      conditionalPanel(
        'input.data === "top_pos"'
      
    ),
    
    conditionalPanel(
      'input.data === "beat"'
      
    ),
    
    conditionalPanel(
      'input.data === "pricing"'
    ),
    
    conditionalPanel(
      'input.data === "partner"'
    ), 
    
    conditionalPanel(
      'input.data==="plot"'
    ),
      
      mainPanel(
        tabsetPanel(
          id = 'data',
          tabPanel("Adv_Data", DT::dataTableOutput("mytable1")),
          tabPanel("Top_position_Share", DT::dataTableOutput("mytable3")),
          tabPanel("Beat_Share", DT::dataTableOutput("mytable4")),
          tabPanel("Advertiser Pricing", DT::dataTableOutput("mytable5")),
          tabPanel("Partner_Share", DT::dataTableOutput("mytable6")),
          tabPanel("Chart", plotly::plotlyOutput("plot"))
        )
      )
     )
    )
  
  


server <- function(input, output) {
  
  dataset1 = dataset[sample(nrow(dataset), 1000), ]
  output$mytable1 <- DT::renderDataTable({
    DT::datatable(dataset1[, input$POS, drop = FALSE])
  })
  
  output$mytable3 <- DT::renderDataTable({
    DT::datatable(top_pos, options = list(orderClasses = TRUE)) 
    })
  
  output$mytable4 <- DT::renderDataTable({
    DT::datatable(beat, options = list(orderClasses = TRUE))
  })
  
  output$mytable5 <- DT::renderDataTable({
    DT::datatable(adv_dev, options = list(orderClasses = TRUE)) 
  })
  
    output$plot <- renderPlotly({
      plot_ly(adv_dev, x =~insert_date, y =~pricing)
    })
  
  output$mytable6 <- DT::renderDataTable({
    DT::datatable(partner, options = list(orderClasses = TRUE))
  })  
  
}

shinyApp(ui, server)