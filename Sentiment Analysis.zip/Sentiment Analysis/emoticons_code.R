setwd("C:/Users/Jane/Desktop/410/PROJECT")

#Loading the training data set#
arizona <- read.csv("arizona.csv", header=TRUE)
text <- arizona$x
text<- gsub("@\\w+", " ", text) #Remove username mentions in tweets - they start with @ symbol.
text <- gsub("http.+ |http.+$", " ", text)
text <- gsub("rt", " ", text) 
text <- gsub("RT", " ", text)#Remove RT so that duplicates are easy to identify
text <- unique(text)
write.csv(text,'arizona_1.csv')
arizona1 <- read.csv('arizona_1.csv',header=TRUE)

#Emoticons
emoticons <- read.csv("emoticon.csv", header = F)

names(emoticons) <- c("unicode", "bytes","description")
emoji.frequency <- matrix(NA, nrow = nrow(arizona1), ncol = nrow(emoticons))

for(i in 1:nrow(emoticons))
{
  
  
  emoji.frequency[,i] <- regexpr(emoticons$bytes[i],arizona1$x, useBytes = T )
  
}

emoji.per.tweet <- rowSums(emoji.frequency > -1)

emoji.indexes <- which( emoji.per.tweet > 0) 
emoji.ds <- NULL

for(i in emoji.indexes){
  
  valid.cols <- which(emoji.frequency[i,]>-1)
  
  for(j in valid.cols){
    
    emoji.ds <- rbind(cbind(arizona1[i,], emoticons[j,]), emoji.ds)
    
  }
  
}

write.csv(emoji.ds,'arizonaemoticons.csv')

arizona1 <- read.csv('arizona_1.csv',header=TRUE)
text<-arizona1$x
text <- gsub("[[:punct:]]", " ", text)
text <- gsub("^ ", "", text) #Leading blanks
text <- gsub(" $", "", text) #Trailing blanks
text <- gsub(" +", " ", text)
text <- iconv(text, to = "ASCII", sub = " ")
text <- gsub("^ ", "", text) #Leading blanks
text <- gsub(" $", "", text) #Trailing blanks
text <- gsub(" +", " ", text)
text <- unique(text)


write.csv(text,'arizona_2.csv')